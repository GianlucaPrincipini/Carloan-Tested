package business.exception;

public class FasciaIndexException extends CarloanException {
	
	
	public FasciaIndexException(String string) {
		super(string);
	}

}
