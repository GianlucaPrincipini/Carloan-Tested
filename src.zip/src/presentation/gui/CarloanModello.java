package presentation.gui;

public class CarloanModello extends CarloanStage{
	public CarloanModello() {
		super("SchermataModello.fxml", null);
	}
	
	public CarloanModello(Object entity) {
		super("SchermataModello.fxml", entity);
	}
}
