package presentation.gui;

public class CarloanMainStage extends CarloanStage{

	public CarloanMainStage() {
		super("MainStage.fxml", null);
		setTitle("Carloan");
		setHeight(720);
		setWidth(1280);
	}

}
