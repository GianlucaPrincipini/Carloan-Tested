package presentation.gui;

public class CarloanOperatore extends CarloanStage{
	
	public CarloanOperatore(){
		super("SchermataOperatore.fxml", null);
		setTitle("Immissione Operatore");
	}
	
	public CarloanOperatore(Object entity) {
		super("SchermataOperatore.fxml", entity);
		setTitle("Immissione Operatore");
	}
}
