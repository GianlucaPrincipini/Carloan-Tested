package business.entity;

public interface Entity extends Comparable<Entity>{

}
