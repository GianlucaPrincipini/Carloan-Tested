package presentation.gui.controller.table;

import javafx.fxml.Initializable;

public interface TableController extends Initializable{

	public String getPrimaryKey();
}
