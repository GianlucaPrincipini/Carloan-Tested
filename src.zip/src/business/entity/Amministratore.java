package business.entity;

public class Amministratore extends Operatore {
	
}