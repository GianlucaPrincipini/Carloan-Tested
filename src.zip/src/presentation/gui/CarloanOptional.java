package presentation.gui;

public class CarloanOptional extends CarloanStage{
	
	public CarloanOptional(){
		super("SchermataOptional.fxml", null);
		setTitle("Immissione Optional");
	}
	
	public CarloanOptional(Object entity) {
		super("SchermataOptional.fxml", entity);
		setTitle("Immissione Optional");
	}
}
