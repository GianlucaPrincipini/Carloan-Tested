package business.applicationservice;

public interface ApplicationService {

}
