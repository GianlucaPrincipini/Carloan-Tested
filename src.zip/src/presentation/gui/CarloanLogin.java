package presentation.gui;

public class CarloanLogin extends CarloanStage{

	public CarloanLogin() {
		super("Login.fxml", null);
		setTitle("Login");
	}

}
