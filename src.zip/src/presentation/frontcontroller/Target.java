package presentation.frontcontroller;

public interface Target {

}
