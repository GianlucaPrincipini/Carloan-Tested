package business.checker;

import business.entity.Optional;
import business.exception.IntegrityException;

public class CheckerOptional implements Checker<Optional>{

	@Override
	public void check(Optional entity) throws IntegrityException {
		
	}

	@Override
	public void isModifiable(Optional entity) throws IntegrityException {

	}

}
