package business.exception;

public class IntegrityException extends CarloanException{
	
	public IntegrityException(){}
	public IntegrityException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
