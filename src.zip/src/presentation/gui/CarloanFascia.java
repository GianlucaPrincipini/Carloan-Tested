package presentation.gui;

public class CarloanFascia extends CarloanStage{
	
	public CarloanFascia(){
		super("SchermataFascia.fxml", null);
		setTitle("Immissione Fascia");
	}
	
	public CarloanFascia(Object entity) {
		super("SchermataFascia.fxml", entity);
		setTitle("Immissione Fascia");
	}
}
